# Algoritmer-og-Datastruktur
Oppgaver
